export const maxDuration = 30

type ClientMessage = {
  role: "user" | "assistant"
  content: string
}

type StoredConversation = {
  messages: ClientMessage[]
  expiresAt: number
}

const CONVO_TTL_MS = 60 * 60 * 1000 // 1 hour
const conversations = new Map<string, StoredConversation>()

function cleanupExpired() {
  const now = Date.now()
  for (const [k, v] of conversations) {
    if (v.expiresAt <= now) conversations.delete(k)
  }
}

export async function POST(req: Request) {
  try {
    const { messages, sessionId }: { messages: ClientMessage[]; sessionId?: string } = await req.json()
    cleanupExpired()
    const sid = sessionId || crypto.randomUUID()

    const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY // support either var name
    if (!apiKey) {
      return new Response("Missing GOOGLE_API_KEY (or GEMINI_API_KEY)", { status: 500 })
    }

    // Map client messages to Gemini "contents" format
    const contents = (messages || []).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }))

    const preferredModel = process.env.GEMINI_MODEL || "gemini-1.5-flash"
    const candidateModels = [preferredModel, "gemini-1.5-flash-001", "gemini-1.5-flash-latest"]

    async function tryFetch(model: string) {
      const url =
        "https://generativelanguage.googleapis.com/v1/models/" +
        encodeURIComponent(model) +
        ":streamGenerateContent?alt=sse&key=" +
        encodeURIComponent(apiKey)

      return fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents }),
        signal: req.signal,
      })
    }

    const toStore = (messages || []).filter((m) => !(m.role === "assistant" && !m.content))
    conversations.set(sid, { messages: toStore, expiresAt: Date.now() + CONVO_TTL_MS })

    let upstream: Response | null = null
    for (const model of candidateModels) {
      const res = await tryFetch(model)
      if (res.ok && res.body) {
        upstream = res
        break
      }

      // If explicitly NOT_FOUND on a model, try next fallback; otherwise bubble up error
      if (res.status === 404) {
        // try next model
        continue
      } else {
        const errText = await res.text().catch(() => "")
        return new Response(`Upstream error: ${res.status} ${res.statusText}\n${errText}`, { status: 502 })
      }
    }

    if (!upstream || !upstream.body) {
      return new Response(
        "No compatible model found (tried: " + candidateModels.join(", ") + "). Set GEMINI_MODEL to a valid model.",
        { status: 502 },
      )
    }

    // Parse SSE and stream just the text deltas to the client
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const decoder = new TextDecoder()
        const encoder = new TextEncoder()
        const reader = upstream!.body!.getReader()
        let buffer = ""
        let assistantAccum = ""

        try {
          while (true) {
            const { value, done } = await reader.read()
            if (done) break
            buffer += decoder.decode(value, { stream: true })

            // Process complete lines
            const lines = buffer.split("\n")
            buffer = lines.pop() ?? ""

            for (const raw of lines) {
              const line = raw.trim()
              if (!line.startsWith("data:")) continue

              const data = line.slice(5).trim()
              if (data === "[DONE]") {
                controller.close()
                conversations.set(sid, {
                  messages: [...toStore, { role: "assistant", content: assistantAccum }],
                  expiresAt: Date.now() + CONVO_TTL_MS,
                })
                return
              }

              try {
                const json = JSON.parse(data)
                const parts = json?.candidates?.[0]?.content?.parts ?? json?.candidates?.[0]?.delta?.parts ?? []
                let text = ""
                for (const p of parts) {
                  if (p?.text) text += p.text
                }
                if (text) {
                  assistantAccum += text
                  controller.enqueue(encoder.encode(text))
                }
              } catch {
                // Ignore non-JSON lines
              }
            }
          }
        } catch (err) {
          try {
            controller.error(err)
          } catch {}
        } finally {
          if (assistantAccum) {
            conversations.set(sid, {
              messages: [...toStore, { role: "assistant", content: assistantAccum }],
              expiresAt: Date.now() + CONVO_TTL_MS,
            })
         console.log(JSON.stringify(Object.fromEntries(conversations), null, 2))
          }
          try {
            controller.close()
          } catch {}
        }
      },
    })

    return new Response(stream, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
      },
    })
  } catch (err: any) {
    return new Response("Bad Request", { status: 400 })
  }
}
