import ChatView from "../components/chat-view"

export default function Page() {
  return <ChatView />
}
